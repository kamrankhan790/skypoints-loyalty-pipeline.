# SkyPoints member and redemption pipeline

This is my solution to the Incubyte data engineer assessment. The airline sends two files
every day: a pipe-delimited file of members and a JSON file of mileage redemptions. The job
is to load the members, split them into one table per country, and turn the JSON into a
table I can join back to the members.

I wrote the SQL for Snowflake. I also wrote the same rules in Python so I could test them
on my laptop.

**What I have and haven't run:** the Python code and its 21 tests run fine. I have not run
the SQL files in a real Snowflake account yet, so expect a few small fixes when I do.

## How the data moves

```
members_YYYYMMDD.txt  ->  raw.member_feed  ->  stg.member  ->  one table per country
redemptions_YYYYMMDD.json  ->  raw.redemption_feed  ->  core.fct_redemption
```

- **raw**: everything stored as text, exactly as it arrived, so nothing is lost if a value is bad.
- **stg**: real data types, plus the Age and Stale_Member columns.
- **country tables**: India, USA, Australia, plus Philippines and Canada for the other
  countries in the sample file.

## Where to find each deliverable

| What was asked | File |
|---|---|
| Create table queries | `sql/01_ddl.sql` |
| Load staging with Age and Stale_Member | `sql/02_load_staging.sql` |
| Split by country, latest record wins | `sql/03_country_split.sql` |
| Flatten the JSON and join to members | `sql/04_redemptions.sql` |
| Validations | `sql/05_validations.sql` |

The Python version of the rules is in `python/skypoints/`, and the tests are in `tests/`.

## The three country files

I also got three small Excel files, one each for India, USA and Australia. They don't have
the same columns, so the country tables don't either.

- **India** has an Individual/Corporate column. Rahul is marked Corporate but has a personal
  date of birth, which looks odd, so I flag it.
- **USA** has no date of birth, so there is no Age for those members. The dates are stored as
  plain numbers that lost their leading zero (6152022 really means 15 June 2022), so I put
  the zero back.
- **Australia** has the word `NULL` typed into Mike's date of birth, and Jonnathan's
  enrollment date is 2021-13-13, which isn't a real date. Enrollment date is required, so
  I reject that row and write it to the reject table. Mike's `NULL` I treat as missing.

The column names also differ between files (`Unique ID` vs `ID`, `Tier Type` vs `TierCode`),
so I match columns by name, not by position.

`python/build_workbook.py` runs the three files through all of this and writes
`data/SkyPoints_Country_Tables.xlsx`. Age and Stale are real Excel formulas there, so if you
change the as-of date or the 90-day limit on the Assumptions sheet, they recalculate.
With the as-of date 2026-11-21: India 3 rows loaded, USA 3 loaded, Australia 2 loaded and 1 rejected.

## Choices I made and why

- **Age and Stale use the file's date, not today's date.** That way, loading an old file
  again gives the same answer. Age is completed years. A member is stale if more than 90
  days have passed since the last flight (exactly 90 is not stale). If there's no flight
  date I leave it blank instead of calling the member stale.
- **Latest record wins.** If the same member shows up in a newer file under a different
  country, the newer one is kept and the member is removed from the old country's table. I
  keep a small lookup table of which country each member is in, so I don't have to search
  every country table. An old file loaded late can't overwrite newer data.
- **Members are keyed as country plus ID** for the three Excel files (`IND-1`, `USA-1`),
  because every one of those files numbers its members 1, 2, 3. The catch: these files can't
  show a member moving countries unless the airline gives us one ID that stays the same everywhere.
- **Built for large files.** Files are loaded in bulk, each day's batch is processed on its
  own, and updates use MERGE instead of wiping and reloading a table.
- **Redemptions:** one row per transaction. If a PENDING redemption comes back later as
  COMPLETED, the new row replaces the old one. The join to members is a LEFT JOIN, so
  redemptions for members we don't have still show up instead of vanishing.

## Problems I noticed in the sample data

1. The spec says Member Name is the key column. Names repeat (Mike is in both the USA and
   Australia files), so I treat Member ID as the real key and also flag repeated names.
2. Country codes are inconsistent: USA, IND, PHIL, CAN, AU. I map them through a small
   reference table and block any code I don't recognise, since I wouldn't know where to put the row.
3. In the staging sample the date of birth `3051985` lost its leading zero. I put it back and log a warning.
4. A date of birth like 03051985 could mean 3 May or 5 March. I assumed day first.
5. Member IDs in the sample are 4 to 6 digits, while the spec allows 18. That's fine, but worth asking about.
6. The staging sample looks shifted: Agent_Name is empty for most rows, and the headers say
   `County` and `FLAG`. Reading by header name avoids depending on column order.
7. Post Code is in the spec but not in the sample file, so I treat it as optional.
8. Every sample row has the same dates, and all of them are years old. It looks like placeholder data.

## Things I'd ask the business

- Is date of birth day-first or month-first?
- Is the tier list GLD, SLV, PLT, BRZ? The sample only shows three of them.
- If the same Member ID appears twice in one day's file, should we reject it or merge it?
- Besides `A`, what other values can Is_Active hold?
- Can the Excel country files get a member ID that is the same across countries?

## What's not done

- The Excel country files go through the Python code, not through the SQL staging step. In a
  real setup I'd point the SQL at them too.
- There are no SQL checks yet for the exact quirks in those three files (the `NULL` text, the
  zero-less dates). The Python code has them.
- Nothing schedules the daily run yet.

## Running the tests

```
pip install pytest
pytest tests
```
